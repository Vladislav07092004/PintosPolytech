
/*
  File for 'test-new-alg' task implementation.
*/

#include <stdio.h>
#include "tests/threads/tests.h"
#include "threads/malloc.h"
#include "threads/thread.h"
#include "threads/synch.h"
#include "devices/timer.h"

static void func(void* aux) {
  struct thread* t = thread_current();
  while (t->ticks < t->cpu_burst) {
    msg("thread %s (priority %d, cpu_burst %d) %d ticks", t->name, t->orig_priority, t->cpu_burst, t->ticks);
  }  
}

void test_new_alg(void) 
{
  thread_set_priority(63);
  thread_create_burst("Proc0", 56, 11, func, 0);
  thread_create_burst("Proc1", 10, 2, func, 0);
  thread_create_burst("Proc2", 58, 3, func, 0);
  thread_create_burst("Proc3", 3, 5, func, 0);  
  thread_set_priority(1);
}


