#include "userprog/syscall.h"
#include <stdio.h>
#include <syscall-nr.h>
#include "threads/interrupt.h"
#include "threads/thread.h"
#include "threads/vaddr.h"
#include "filesys/filesys.h"
#include "filesys/file.h"
#include "process.h"
#include "devices/input.h"
#include "devices/shutdown.h"
#include "pagedir.h"

static void syscall_handler(struct intr_frame *);
static int handle_file_operations(int syscall_num, int* args);
static int handle_process_operations(int syscall_num, int* args);
static bool validate_memory_access(const void* ptr, size_t size);
static bool validate_string_access(const char* str);

/* Завершает текущий поток с указанным кодом выхода */
void terminate_thread(int exit_code) {
    struct thread *cur = thread_current();
    cur->exitcode = exit_code;
    thread_exit();
}

/* Проверяет доступность области памяти для чтения/записи */
static bool validate_memory_access(const void* ptr, size_t size) {
    const uint8_t *p = ptr;
    struct thread *cur = thread_current();
    
    while (size > 0) {
        // Проверка, что указатель не выходит за границы пользовательского пространства
        if (p >= (const uint8_t *)PHYS_BASE)
            return false;
            
        // Получаем страницу из таблицы страниц
        void *page = pagedir_get_page(cur->pagedir, p);
        if (!page)
            return false;
            
        // Вычисляем оставшееся место на странице
        size_t remaining = ((const uint8_t *)pg_round_down(p) + PGSIZE) - p;
        size -= (size > remaining) ? remaining : size;
        p += remaining;
    }
    
    return true;
}

/* Проверяет доступность строки (до нуль-терминатора) */
static bool validate_string_access(const char* str) {
    struct thread *cur = thread_current();
    
    while (1) {
        // Проверка границ пользовательского пространства
        if (str >= (const char *)PHYS_BASE)
            return false;
            
        // Получаем страницу из таблицы страниц
        void *page = pagedir_get_page(cur->pagedir, str);
        if (!page)
            return false;
            
        // Проверяем строку в пределах текущей страницы
        size_t remaining = ((const char *)pg_round_down(str) + PGSIZE) - str;
        for (size_t i = 0; i < remaining; i++) {
            if (str[i] == '\0')
                return true;
        }
        
        // Переходим к следующей странице
        str += remaining;
    }
    
    return true;
}

/* Обрабатывает файловые операции (создание, удаление, чтение, запись и т.д.) */
static int handle_file_operations(int syscall_num, int* args) {
    struct thread *cur = thread_current();
    
    switch (syscall_num) {
        case SYS_CREATE: {  // Создание файла
            char *filename = (char *)args[0];
            if (!validate_string_access(filename))
                terminate_thread(-1);
            return filesys_create(filename, args[1]);
        }
        
        case SYS_REMOVE: {  // Удаление файла
            char *filename = (char *)args[0];
            if (!validate_string_access(filename))
                terminate_thread(-1);
            return filesys_remove(filename);
        }
        
        case SYS_OPEN: {  // Открытие файла
            char *filename = (char *)args[0];
            if (!validate_string_access(filename))
                terminate_thread(-1);
                
            // Ищем свободный дескриптор файла (начинаем с 2, так как 0 и 1 зарезервированы)
            for (int fd = 2; fd < MAXIMUM_OPEN_FILES; fd++) {
                if (cur->files[fd] == NULL) {
                    cur->files[fd] = filesys_open(filename);
                    return (cur->files[fd] != NULL) ? fd : -1;
                }
            }
            return -1;
        }
        
        case SYS_CLOSE: {  // Закрытие файла
            int fd = args[0];
            if (fd < 0 || fd >= MAXIMUM_OPEN_FILES || cur->files[fd] == NULL)
                return -1;
                
            file_close(cur->files[fd]);
            cur->files[fd] = NULL;
            return 0;
        }
        
        case SYS_FILESIZE: {  // Получение размера файла
            int fd = args[0];
            if (fd < 0 || fd >= MAXIMUM_OPEN_FILES || cur->files[fd] == NULL)
                return -1;
            return file_length(cur->files[fd]);
        }
        
        case SYS_READ: {  // Чтение из файла
            int fd = args[0];
            void *buffer = (void *)args[1];
            unsigned size = args[2];
            
            if (!validate_memory_access(buffer, size))
                terminate_thread(-1);
                
            if (fd == 0) {  // Чтение из STDIN (консоли)
                for (unsigned i = 0; i < size; i++)
                    ((char *)buffer)[i] = input_getc();
                return size;
            }
            
            if (fd < 0 || fd >= MAXIMUM_OPEN_FILES || cur->files[fd] == NULL)
                return -1;
                
            return file_read(cur->files[fd], buffer, size);
        }
        
        case SYS_WRITE: {  // Запись в файл
            int fd = args[0];
            const void *buffer = (const void *)args[1];
            unsigned size = args[2];
            
            if (!validate_memory_access(buffer, size))
                terminate_thread(-1);
                
            if (fd == 1) {  // Запись в STDOUT (консоль)
                putbuf(buffer, size);
                return size;
            }
            
            if (fd < 0 || fd >= MAXIMUM_OPEN_FILES || cur->files[fd] == NULL)
                return -1;
                
            return file_write(cur->files[fd], buffer, size);
        }
        
        default:
            return -1;
    }
}

/* Обрабатывает операции с процессами (запуск, завершение, ожидание) */
static int handle_process_operations(int syscall_num, int* args) {
    switch (syscall_num) {
        case SYS_EXIT:  // Завершение процесса
            terminate_thread(args[0]);
            return 0;
            
        case SYS_EXEC: {  // Запуск нового процесса
            char *cmd = (char *)args[0];
            if (!validate_string_access(cmd))
                terminate_thread(-1);
            return process_execute(cmd);
        }
        
        case SYS_WAIT:  // Ожидание завершения дочернего процесса
            return process_wait(args[0]);
            
        default:
            return -1;
    }
}

/* Основной обработчик системных вызовов */
static void syscall_handler(struct intr_frame *f) {
    // Проверяем доступность указателя на стек
    if (!validate_memory_access(f->esp, sizeof(int)))
        terminate_thread(-1);
        
    // Получаем номер системного вызова
    int syscall_num = *(int *)f->esp;
    
    // Обработка вызова shutdown
    if (syscall_num == SYS_HALT) {
        shutdown_power_off();
        return;
    }
    
    // Получаем аргументы системного вызова
    int *args = (int *)f->esp + 1;
    
    // Проверяем доступность аргументов в зависимости от типа системного вызова
    switch (syscall_num) {
        case SYS_CREATE:  // create требует 2 аргумента
            if (!validate_memory_access(args, 2 * sizeof(int)))
                terminate_thread(-1);
            break;
            
        case SYS_READ:    // read/write требуют 3 аргумента
        case SYS_WRITE:
            if (!validate_memory_access(args, 3 * sizeof(int)))
                terminate_thread(-1);
            break;
            
        default:  // Остальные - 1 аргумент
            if (!validate_memory_access(args, sizeof(int)))
                terminate_thread(-1);
    }
    
    // Перенаправляем вызов соответствующему обработчику
    if (syscall_num <= SYS_WAIT) {
        f->eax = handle_process_operations(syscall_num, args);
    } else {
        f->eax = handle_file_operations(syscall_num, args);
    }
}

/* Инициализация системы системных вызовов */
void syscall_init(void) {
    intr_register_int(0x30, 3, INTR_ON, syscall_handler, "syscall");
}
