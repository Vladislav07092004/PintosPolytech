#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>

#define MIN_FILE_EXTEND 1024  // Минимальное расширение файла - 1KB

// Структура для работы с файлом чисел
typedef struct {
    int fd;         // Файловый дескриптор
    size_t size;    // Текущий размер файла в байтах
    size_t count;   // Количество чисел в файле
} NumberFile;

// Открывает или создает файл для работы
bool open_number_file(const char* filename, NumberFile* nf) {
    nf->fd = open(filename, O_RDWR | O_CREAT, 0644);
    if (nf->fd < 0) return false;
    
    struct stat st;
    if (fstat(nf->fd, &st) < 0) return false;
    
    nf->size = st.st_size;
    nf->count = nf->size / sizeof(int);
    return true;
}

// Закрывает файл
void close_number_file(NumberFile* nf) {
    if (nf->fd >= 0) close(nf->fd);
}

// Увеличивает размер файла при необходимости
bool extend_file_if_needed(NumberFile* nf, size_t needed) {
    if (nf->size >= needed) return true;
    
    // Вычисляем новый размер (минимум +1KB)
    size_t new_size = nf->size + (needed - nf->size > MIN_FILE_EXTEND ? 
                        needed - nf->size : MIN_FILE_EXTEND);
    
    if (ftruncate(nf->fd, new_size) < 0) return false;
    nf->size = new_size;
    return true;
}

// Бинарный поиск числа в файле
bool find_number(NumberFile* nf, int num, off_t* pos) {
    if (nf->count == 0) return false;
    
    off_t left = 0;
    off_t right = nf->count - 1;
    
    while (left <= right) {
        off_t mid = left + (right - left) / 2;
        int current;
        
        if (pread(nf->fd, &current, sizeof(int), mid * sizeof(int)) != sizeof(int))
            return false;
        
        if (current == num) {
            if (pos) *pos = mid;
            return true;
        } else if (current < num) {
            left = mid + 1;
        } else {
            right = mid - 1;
        }
    }
    
    if (pos) *pos = left;
    return false;
}

// Добавляет число в файл (если его там нет)
bool add_number(NumberFile* nf, int num) {
    off_t pos;
    if (find_number(nf, num, &pos)) return true; // Число уже есть
    
    // Увеличиваем файл при необходимости
    if (!extend_file_if_needed(nf, (nf->count + 1) * sizeof(int)))
        return false;
    
    // Сдвигаем существующие числа для вставки нового
    for (off_t i = nf->count - 1; i >= pos; i--) {
        int val;
        if (pread(nf->fd, &val, sizeof(int), i * sizeof(int)) != sizeof(int))
            return false;
        if (pwrite(nf->fd, &val, sizeof(int), (i + 1) * sizeof(int)) != sizeof(int))
            return false;
    }
    
    // Записываем новое число
    if (pwrite(nf->fd, &num, sizeof(int), pos * sizeof(int)) != sizeof(int))
        return false;
    
    nf->count++;
    return true;
}

// Удаляет число из файла (если оно есть)
bool delete_number(NumberFile* nf, int num) {
    off_t pos;
    if (!find_number(nf, num, &pos)) return true; // Числа нет - ничего делать не нужно
    
    // Сдвигаем числа после удаляемого
    for (off_t i = pos + 1; i < nf->count; i++) {
        int val;
        if (pread(nf->fd, &val, sizeof(int), i * sizeof(int)) != sizeof(int))
            return false;
        if (pwrite(nf->fd, &val, sizeof(int), (i - 1) * sizeof(int)) != sizeof(int))
            return false;
    }
    
    // Уменьшаем размер файла
    nf->count--;
    if (ftruncate(nf->fd, nf->count * sizeof(int)) < 0) return false;
    nf->size = nf->count * sizeof(int);
    
    return true;
}

// Выводит справку по программе
void print_help() {
    printf("Использование:\n");
    printf("  digset add [файл] [число]  - добавить число в файл\n");
    printf("  digset find [файл] [число] - проверить наличие числа в файле\n");
    printf("  digset del [файл] [число]  - удалить число из файла\n");
    printf("  digset help                - показать эту справку\n");
}

int main(int argc, const char* argv[]) {
    if (argc < 2) {
        print_help();
        return EXIT_FAILURE;
    }
    
    const char* command = argv[1];
    
    if (strcmp(command, "help") == 0) {
        print_help();
        return EXIT_SUCCESS;
    }
    
    if (argc != 4) {
        fprintf(stderr, "Ошибка: неверное количество аргументов\n");
        print_help();
        return EXIT_FAILURE;
    }
    
    const char* filename = argv[2];
    int number = atoi(argv[3]);
    
    NumberFile nf = {-1, 0, 0};
    if (!open_number_file(filename, &nf)) {
        perror("Ошибка при работе с файлом");
        return EXIT_FAILURE;
    }
    
    bool success = false;
    
    if (strcmp(command, "add") == 0) {
        success = add_number(&nf, number);
        if (success) {
            printf("Число %d успешно добавлено в файл %s\n", number, filename);
        } else {
            fprintf(stderr, "Ошибка при добавлении числа %d в файл %s\n", number, filename);
        }
    } 
    else if (strcmp(command, "find") == 0) {
        bool found = find_number(&nf, number, NULL);
        printf("Число %d %s найдено в файле %s\n", 
               number, found ? "" : "не", filename);
        success = true;
    } 
    else if (strcmp(command, "del") == 0) {
        success = delete_number(&nf, number);
        if (success) {
            printf("Число %d успешно удалено из файла %s\n", number, filename);
        } else {
            fprintf(stderr, "Ошибка при удалении числа %d из файла %s\n", number, filename);
        }
    } 
    else {
        fprintf(stderr, "Ошибка: неизвестная команда '%s'\n", command);
        print_help();
    }
    
    close_number_file(&nf);
    return success ? EXIT_SUCCESS : EXIT_FAILURE;
}
