#include <stdio.h>
#include <syscall.h>

int main(int argc, char *argv[]) 
{
    if (argc != 3) {
        printf("Usage: %s <lower_bound> <upper_bound>\n", argv[0]);
        return EXIT_FAILURE;
    }

    int lower = atoi(argv[1]);
    int upper = atoi(argv[2]);

    if (lower < 2) lower = 2;  // Первое простое число - 2
    if (upper < lower) {
        printf("Invalid range.\n");
        return EXIT_FAILURE;
    }

    // Выделяем память для решета
    bool *is_prime = (bool *)malloc((upper + 1) * sizeof(bool));
    if (!is_prime) {
        printf("Memory allocation failed.\n");
        return EXIT_FAILURE;
    }

    // Инициализация решета
    for (int i = 0; i <= upper; i++) {
        is_prime[i] = true;
    }
    is_prime[0] = is_prime[1] = false;

    // Решето Эратосфена
    for (int i = 2; i * i <= upper; i++) {
        if (is_prime[i]) {
            for (int j = i * i; j <= upper; j += i) {
                is_prime[j] = false;
            }
        }
    }

    // Вывод простых чисел в заданном диапазоне
    for (int i = lower; i <= upper; i++) {
        if (is_prime[i]) {
            printf("%d\n", i);
        }
    }

    free(is_prime);
    return EXIT_SUCCESS;
}
