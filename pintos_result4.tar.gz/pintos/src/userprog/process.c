#include "userprog/process.h"
#include <debug.h>
#include <inttypes.h>
#include <round.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "userprog/gdt.h"
#include "userprog/pagedir.h"
#include "userprog/tss.h"
#include "filesys/directory.h"
#include "filesys/file.h"
#include "filesys/filesys.h"
#include "threads/flags.h"
#include "threads/init.h"
#include "threads/interrupt.h"
#include "threads/palloc.h"
#include "threads/thread.h"
#include "threads/vaddr.h"

static thread_func start_process NO_RETURN;
static bool load (const char *cmdline, void (**eip) (void), void **esp);
static char process_name[16];  // Буфер для имени процесса
static struct semaphore process_semaphore;  // Семафор для синхронизации

/* Выделяет имя процесса из командной строки */
static void extract_filename(const char *src, char *dest) {
    int i = 0;
    while (i < 15 && src[i] != ' ' && src[i] != '\0') {
        dest[i] = src[i];
        i++;
    }
    dest[i] = '\0';
}

/* Инициализирует аргументы процесса */
static void init_process_args(const char *file_name) {
    sema_init(&process_semaphore, 0);
    extract_filename(file_name, process_name);
}

/* Обрабатывает завершение процесса */
static void cleanup_process_resources(void) {
    struct thread *cur = thread_current();
    if (cur->pagedir != NULL) {
        pagedir_activate(NULL);
        pagedir_destroy(cur->pagedir);
        cur->pagedir = NULL;
    }
}

/* Проверяет валидность ELF-заголовка */
static bool verify_elf_header(const struct Elf32_Ehdr *ehdr) {
    return memcmp(ehdr->e_ident, "\177ELF\1\1\1", 7) == 0 &&
           ehdr->e_type == 2 &&
           ehdr->e_machine == 3 &&
           ehdr->e_version == 1 &&
           ehdr->e_phentsize == sizeof(struct Elf32_Phdr) &&
           ehdr->e_phnum <= 1024;
}

/* Загружает сегмент программы в память */
static bool load_segment_from_file(struct file *file, off_t ofs, 
                                 uint8_t *upage, uint32_t read_bytes,
                                 uint32_t zero_bytes, bool writable) {
    ASSERT((read_bytes + zero_bytes) % PGSIZE == 0);
    ASSERT(pg_ofs(upage) == 0);
    ASSERT(ofs % PGSIZE == 0);

    file_seek(file, ofs);
    while (read_bytes > 0 || zero_bytes > 0) {
        size_t page_read_bytes = read_bytes < PGSIZE ? read_bytes : PGSIZE;
        size_t page_zero_bytes = PGSIZE - page_read_bytes;

        if (!load_segment(file, ofs, upage, page_read_bytes, 
                         page_zero_bytes, writable))
            return false;

        read_bytes -= page_read_bytes;
        zero_bytes -= page_zero_bytes;
        upage += PGSIZE;
        ofs += page_read_bytes;
    }
    return true;
}

/* Настраивает аргументы командной строки в стеке */
static bool setup_command_line_args(void **esp, const char *cmd_line) {
    char *argv[64];
    int argc = 0;
    char *token, *save_ptr;
    char cmd_line_copy[strlen(cmd_line) + 1];
    
    strlcpy(cmd_line_copy, cmd_line, sizeof(cmd_line_copy));
    
    for (token = strtok_r(cmd_line_copy, " ", &save_ptr); token != NULL;
         token = strtok_r(NULL, " ", &save_ptr)) {
        if (argc >= 64) return false;
        argv[argc++] = token;
    }

    /* Выравнивание стека */
    *esp = (void *)((uintptr_t)*esp & ~7);

    /* Помещаем аргументы в стек */
    for (int i = argc - 1; i >= 0; i--) {
        size_t len = strlen(argv[i]) + 1;
        *esp -= len;
        memcpy(*esp, argv[i], len);
        argv[i] = *esp;
    }

    /* Помещаем указатели на аргументы */
    void *argv_ptr = *esp;
    *esp -= (argc + 1) * sizeof(char *);
    memcpy(*esp, &argv_ptr, sizeof(char *));
    
    /* Помещаем argc и адрес возврата */
    *esp -= sizeof(int);
    *(int *)*esp = argc;
    
    return true;
}

/* Основные функции */

tid_t process_execute(const char *file_name) {
    char *fn_copy;
    tid_t tid;
    
    init_process_args(file_name);
    
    fn_copy = palloc_get_page(0);
    if (fn_copy == NULL)
        return TID_ERROR;
    strlcpy(fn_copy, file_name, PGSIZE);

    tid = thread_create(process_name, PRI_DEFAULT, start_process, fn_copy);
    if (tid == TID_ERROR) {
        palloc_free_page(fn_copy);
        return TID_ERROR;
    }
    
    return tid;
}

int process_wait(tid_t child_tid UNUSED) {
    sema_down(&process_semaphore);
    return -1;
}

void process_exit(void) {
    struct thread *cur = thread_current();
    cleanup_process_resources();
    printf("%s: exit(%d)\n", cur->name, cur->exit_status);
    sema_up(&process_semaphore);
}

bool load(const char *file_name, void (**eip)(void), void **esp) {
    struct thread *t = thread_current();
    struct Elf32_Ehdr ehdr;
    struct file *file = NULL;
    bool success = false;

    t->pagedir = pagedir_create();
    if (t->pagedir == NULL)
        goto done;

    file = filesys_open(process_name);
    if (file == NULL) {
        printf("load: %s: open failed\n", process_name);
        goto done;
    }

    if (file_read(file, &ehdr, sizeof(ehdr)) != sizeof(ehdr) || 
        !verify_elf_header(&ehdr)) {
        printf("load: %s: error loading executable\n", process_name);
        goto done;
    }

    /* Загрузка сегментов программы */
    off_t file_ofs = ehdr.e_phoff;
    for (int i = 0; i < ehdr.e_phnum; i++) {
        struct Elf32_Phdr phdr;
        
        file_seek(file, file_ofs);
        if (file_read(file, &phdr, sizeof(phdr)) != sizeof(phdr))
            goto done;
        
        if (phdr.p_type == PT_LOAD) {
            uint32_t read_bytes = phdr.p_filesz;
            uint32_t zero_bytes = phdr.p_memsz - phdr.p_filesz;
            bool writable = (phdr.p_flags & PF_W) != 0;
            
            if (!load_segment_from_file(file, phdr.p_offset, 
                                      (void *)phdr.p_vaddr,
                                      read_bytes, zero_bytes, writable))
                goto done;
        }
        
        file_ofs += sizeof(phdr);
    }

    if (!setup_stack(esp) || !setup_command_line_args(esp, file_name))
        goto done;

    *eip = (void (*)(void))ehdr.e_entry;
    success = true;

done:
    if (file != NULL) 
        file_close(file);
    if (!success && t->pagedir != NULL) {
        pagedir_destroy(t->pagedir);
        t->pagedir = NULL;
    }
    return success;
}
