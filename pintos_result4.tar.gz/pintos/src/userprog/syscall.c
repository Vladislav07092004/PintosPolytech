#include "userprog/syscall.h"
#include <stdio.h>
#include <syscall-nr.h>
#include "threads/interrupt.h"
#include "threads/thread.h"
#include "threads/vaddr.h"
#include "devices/shutdown.h"
#include "filesys/filesys.h"
#include "filesys/file.h"

/* Статическая функция для проверки указателей */
static bool is_valid_pointer(const void *ptr) {
    return ptr != NULL && is_user_vaddr(ptr) && pagedir_get_page(thread_current()->pagedir, ptr) != NULL;
}

/* Обработчик для SYS_EXIT */
static void handle_exit(struct intr_frame *f) {
    int exit_code = *((int *)f->esp + 1);
    if (!is_valid_pointer((void *)(f->esp + 4)))
        thread_exit();
    
    struct thread *cur = thread_current();
    cur->exit_status = exit_code;
    printf("%s: exit(%d)\n", cur->name, exit_code);
    thread_exit();
}

/* Обработчик для SYS_WRITE */
static void handle_write(struct intr_frame *f) {
    int fd = *((int *)f->esp + 1);
    const void *buffer = *((const void **)f->esp + 2);
    unsigned size = *((unsigned *)f->esp + 3);
    
    if (!is_valid_pointer(buffer) || !is_valid_pointer(buffer + size - 1))
        return;
    
    if (fd == STDOUT_FILENO) {
        putbuf(buffer, size);
        f->eax = size;
    } else {
        struct file *file = thread_current()->open_files[fd];
        if (file != NULL) {
            f->eax = file_write(file, buffer, size);
        } else {
            f->eax = -1;
        }
    }
}

/* Обработчик для SYS_READ */
static void handle_read(struct intr_frame *f) {
    int fd = *((int *)f->esp + 1);
    void *buffer = *((void **)f->esp + 2);
    unsigned size = *((unsigned *)f->esp + 3);
    
    if (!is_valid_pointer(buffer) || !is_valid_pointer(buffer + size - 1)) {
        f->eax = -1;
        return;
    }
    
    if (fd == STDIN_FILENO) {
        // Реализация чтения с клавиатуры
        f->eax = 0;
    } else {
        struct file *file = thread_current()->open_files[fd];
        if (file != NULL) {
            f->eax = file_read(file, buffer, size);
        } else {
            f->eax = -1;
        }
    }
}

/* Основной обработчик системных вызовов */
static void syscall_handler(struct intr_frame *f) {
    if (!is_valid_pointer(f->esp)) {
        thread_exit();
        return;
    }

    int syscall_number = *((int *)f->esp);
    
    switch (syscall_number) {
        case SYS_HALT:
            shutdown_power_off();
            break;
        case SYS_EXIT:
            handle_exit(f);
            break;
        case SYS_EXEC:
            // Реализация exec
            break;
        case SYS_WAIT:
            // Реализация wait
            break;
        case SYS_CREATE:
            // Реализация create
            break;
        case SYS_REMOVE:
            // Реализация remove
            break;
        case SYS_OPEN:
            // Реализация open
            break;
        case SYS_FILESIZE:
            // Реализация filesize
            break;
        case SYS_READ:
            handle_read(f);
            break;
        case SYS_WRITE:
            handle_write(f);
            break;
        case SYS_SEEK:
            // Реализация seek
            break;
        case SYS_TELL:
            // Реализация tell
            break;
        case SYS_CLOSE:
            // Реализация close
            break;
        default:
            printf("Unknown system call %d\n", syscall_number);
            thread_exit();
    }
}

void syscall_init(void) {
    intr_register_int(0x30, 3, INTR_ON, syscall_handler, "syscall");
}
