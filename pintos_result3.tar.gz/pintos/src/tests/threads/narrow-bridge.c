/* Narrow bridge synchronization implementation */
#include <stdbool.h>
#include <stdio.h>
#include "tests/threads/tests.h"
#include "threads/thread.h"
#include "threads/synch.h"
#include "narrow-bridge.h"

/* Bridge state tracking */
struct bridge_state {
    int normal_left_queue;
    int normal_right_queue;
    int emergency_left_queue;
    int emergency_right_queue;
    int cars_passed_current_direction;
};

struct bridge_state current_state;

int active_vehicles = 0;
int current_direction = 0; // -1: left, 0: none, 1: right

/* Synchronization primitives */
struct semaphore left_normal_sem;
struct semaphore right_normal_sem;
struct semaphore left_emergency_sem;
struct semaphore right_emergency_sem;

/* Helper functions */
void update_queue_count(enum car_priority priority, enum car_direction direction) {
    if (priority == car_emergency) {
        if (direction == dir_left) {
            ++current_state.emergency_left_queue;
        } else {
            ++current_state.emergency_right_queue;
        }
    } else {
        if (direction == dir_left) {
            ++current_state.normal_left_queue;
        } else {
            ++current_state.normal_right_queue;
        }
    }
}

void decrement_queue_count(enum car_priority priority, enum car_direction direction) {
    if (priority == car_emergency) {
        if (direction == dir_left) {
            current_state.emergency_left_queue--;
        } else {
            current_state.emergency_right_queue--;
        }
    } else {
        if (direction == dir_left) {
            current_state.normal_left_queue--;
        } else {
            current_state.normal_right_queue--;
        }
    }
}

void allow_vehicle_passage(enum car_priority priority, enum car_direction direction) {
    if (priority == car_normal) {
        if (direction == dir_left) {
            sema_up(&left_normal_sem);
        } else {
            sema_up(&right_normal_sem);
        }
    } else {
        if (direction == dir_left) {
            sema_up(&left_emergency_sem);
        } else {
            sema_up(&right_emergency_sem);
        }
    }
    decrement_queue_count(priority, direction);
}

void wait_for_passage(enum car_priority priority, enum car_direction direction) {
    update_queue_count(priority, direction);

    struct semaphore* target_semaphore;
    if (priority == car_normal) {
        target_semaphore = (direction == dir_left) ? &left_normal_sem : &right_normal_sem;
    } else {
        target_semaphore = (direction == dir_left) ? &left_emergency_sem : &right_emergency_sem;
    }
    sema_down(target_semaphore);
}

void initialize_bridge_state(struct bridge_state* state) {
    state->normal_left_queue = 0;
    state->normal_right_queue = 0;
    state->emergency_left_queue = 0;
    state->emergency_right_queue = 0;
    state->cars_passed_current_direction = 0;
}

/* Main functions */
void narrow_bridge_init(void) {
    initialize_bridge_state(&current_state);
    sema_init(&left_normal_sem, 0);
    sema_init(&right_normal_sem, 0);
    sema_init(&left_emergency_sem, 0);
    sema_init(&right_emergency_sem, 0);
}

void arrive_bridge(enum car_priority priority, enum car_direction direction) {
    if (priority == car_normal) {
        thread_yield();
    }
    
    int vehicle_dir = (direction == dir_left) ? -1 : 1;

    if (current_direction == 0) {
        current_direction = vehicle_dir;
        ++active_vehicles;
        return;
    }

    if (current_direction == vehicle_dir) {
        if (active_vehicles < 2) {
            ++active_vehicles;
            return;
        }
        wait_for_passage(priority, direction);
        ++active_vehicles;
        return;
    } else {
        if (active_vehicles == 0) {
            current_direction = vehicle_dir;
            current_state.cars_passed_current_direction = 0;
            ++active_vehicles;
            return;
        } else {
            wait_for_passage(priority, direction);
            ++active_vehicles;
            return;
        }
    }
}

void process_left_direction() {
    if (current_state.emergency_left_queue > 0) {
        allow_vehicle_passage(car_emergency, dir_left);
    }

    if (active_vehicles == 0 && current_state.emergency_left_queue > 0) {
        allow_vehicle_passage(car_emergency, dir_left);
    } else if (current_state.normal_left_queue > 0) {
        allow_vehicle_passage(car_normal, dir_left);
    }
}

void process_right_direction() {
    if (current_state.emergency_right_queue > 0) {
        allow_vehicle_passage(car_emergency, dir_right);
    }

    if (active_vehicles == 0 && current_state.emergency_right_queue > 0) {
        allow_vehicle_passage(car_emergency, dir_right);
    } else if (current_state.normal_right_queue > 0) {
        allow_vehicle_passage(car_normal, dir_right);
    }
}

void exit_bridge(enum car_priority priority, enum car_direction direction) {
    --current_state.cars_passed_current_direction;
    --active_vehicles;

    int left_queue = current_state.normal_left_queue + current_state.emergency_left_queue;
    int right_queue = current_state.normal_right_queue + current_state.emergency_right_queue;

    bool direction_changed = false;

    if (current_state.cars_passed_current_direction >= 2) {
        if (current_direction == -1 && (right_queue > 0 || 
            (current_state.emergency_left_queue > 0 && current_state.emergency_right_queue == 0))) {
            current_direction = 1;
            current_state.cars_passed_current_direction = 0;
            direction_changed = true;
        } else if (current_direction == 1 && (left_queue > 0 || 
                 (current_state.emergency_right_queue > 0 && current_state.emergency_left_queue == 0))) {
            current_direction = -1;
            current_state.cars_passed_current_direction = 0;
            direction_changed = true;
        }
    } else if (active_vehicles == 0 && 
               ((direction == dir_left && current_direction == -1 && left_queue == 0) || 
                (direction == dir_right && current_direction == 1 && right_queue == 0))) {
        current_direction *= -1;
        current_state.cars_passed_current_direction = 0;
        direction_changed = true;
    }

    if (active_vehicles == 1 && direction_changed) {
        current_state.cars_passed_current_direction = -1;
        return;
    }

    if (active_vehicles > 0) return;

    if (current_direction == -1) {
        process_left_direction();
    } else {
        process_right_direction();
    }
}
