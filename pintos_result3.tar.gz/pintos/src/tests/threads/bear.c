/*
  File for 'bear' task implementation.
*/

#include <stdio.h>
#include "tests/threads/tests.h"
#include "threads/malloc.h"
#include "threads/thread.h"
#include "threads/synch.h"
#include "devices/timer.h"

/* Глобальные переменные для синхронизации */
static struct semaphore pot_lock;    // Семафор для доступа к горшку
static struct semaphore bear_sleep;  // Семафор для сна медведя
static unsigned int pot_capacity;    // Вместимость горшка
static unsigned int honey = 0;       // Текущее количество меда

static void init(unsigned int pot_size)
{
    pot_capacity = pot_size;
    honey = 0;
    sema_init(&pot_lock, 1);        // Инициализация семафора доступа к горшку
    sema_init(&bear_sleep, 0);      // Медведь изначально спит
}

static void bear(void* arg UNUSED)
{
    while (true) 
    {
        // Ждем пока горшок наполнится
        sema_down(&bear_sleep);
        
        msg("Bear wakes up and eats all honey!");
        
        // Блокируем доступ к горшку
        sema_down(&pot_lock);
        honey = 0;                  // Медведь съедает весь мед
        sema_up(&pot_lock);         // Разблокируем доступ
        
        msg("Bear goes back to sleep.");
    }
}

static void bee(void* arg UNUSED)
{
    int bee_id = (int)arg;
    
    while (true) 
    {
        // Имитируем сбор меда
        timer_sleep(10);
        
        // Блокируем доступ к горшку
        sema_down(&pot_lock);
        
        if (honey < pot_capacity) 
        {
            honey++;
            msg("Bee %d adds honey. Pot now has %d/%d", bee_id, honey, pot_capacity);
            
            // Если горшок полон, будим медведя
            if (honey == pot_capacity) {
                msg("Bee %d wakes the bear!", bee_id);
                sema_up(&bear_sleep);
            }
        }
        
        sema_up(&pot_lock);
    }
}


void test_bear(unsigned int num_bees, unsigned int pot_size)
{
    unsigned int i;
    init(pot_size);

    // Создаем медведя
    thread_create("bear", PRI_DEFAULT, &bear, NULL);

    // Создаем пчел
    for (i = 0; i < num_bees; i++)
    {
        char name[32];
        snprintf(name, sizeof(name), "bee_%d", i + 1);
        thread_create(name, PRI_DEFAULT, &bee, (void*)(i+1));
    }

    // Даем время на выполнение
    timer_msleep(5000);
    pass();
}
